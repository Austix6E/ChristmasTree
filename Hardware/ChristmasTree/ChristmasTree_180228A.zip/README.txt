Project: LED Driver Test Board

Engineer: Austin Cole

Email: austi01101110@gmail.com
********************************************************************************

Unit = IN
Format = 2:4
Filetype = 274X

Dimensions:
X = 84mm		
Y = 100mm

Layer Count = 2
Thickness = 1.6mm
Copper Wt. = 1 oz
Silkscreen: Top Side

Files:

.DRL    Binary Drill File
.GBL    Bottom Copper
.GBS    Bottom Soldermask
.GD1    Drill Drawing
.GG1    Drill Guide
.GM1	Board Outline
.GTL    Top Copper
.GTO    Top Silkscreen
.GTS    Top Soldermask
.TXT    NC Drill File